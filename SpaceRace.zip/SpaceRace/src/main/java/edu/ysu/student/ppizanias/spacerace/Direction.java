package edu.ysu.student.ppizanias.spacerace;

public enum Direction {
    UP, DOWN;
}
